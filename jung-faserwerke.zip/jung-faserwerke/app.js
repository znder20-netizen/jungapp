function showPage(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function toggleSidebar(){
  document.getElementById("sidebar").classList.toggle("open");
}

let materials = JSON.parse(localStorage.getItem("materials")||"[]");
let products  = JSON.parse(localStorage.getItem("products")||"[]");
let offers    = JSON.parse(localStorage.getItem("offers")||"[]");

function saveAll(){
  localStorage.setItem("materials",JSON.stringify(materials));
  localStorage.setItem("products",JSON.stringify(products));
  localStorage.setItem("offers",JSON.stringify(offers));
}

/* PANEL */
function openPanel(title, contentHTML) {
  document.getElementById("panel-title").innerText = title;
  document.getElementById("panel-content").innerHTML = contentHTML;
  document.body.classList.add("panel-open");
}

function closePanel() {
  document.body.classList.remove("panel-open");
}

/* MATERIALIEN */
function addMaterial(){
  openPanel("Material hinzufügen", `
    <label>Name</label>
    <input id="mat-name" type="text" class="input">

    <label>Preis €/kg</label>
    <input id="mat-price" type="number" class="input">

    <label>Dichte g/cm³</label>
    <input id="mat-density" type="number" class="input">

    <button onclick="saveMaterial()" class="btn-save">Speichern</button>
  `);
}

function saveMaterial(){
  const name = document.getElementById("mat-name").value;
  const price = parseFloat(document.getElementById("mat-price").value);
  const density = parseFloat(document.getElementById("mat-density").value);

  materials.push({ id: Date.now(), name, price, density });
  saveAll();
  renderMaterials();
  closePanel();
}

function renderMaterials(){
  const list=document.getElementById("material-list");
  list.innerHTML="";
  materials.forEach(m=>{
    list.innerHTML+=`<div class="card">
      <strong>${m.name}</strong><br>
      Preis: ${m.price} €/kg<br>
      Dichte: ${m.density} g/cm³<br>
      <button onclick="deleteMaterial(${m.id})">Löschen</button>
    </div>`;
  });
}

function deleteMaterial(id){
  materials=materials.filter(m=>m.id!==id);
  saveAll(); renderMaterials();
}

/* PRODUKTE */
function addProduct(){
  openPanel("Produkt hinzufügen", `
    <label>Name</label>
    <input id="prod-name" type="text" class="input">

    <label>Gewicht (g)</label>
    <input id="prod-weight" type="number" class="input">

    <label>Material wählen</label>
    <select id="prod-material" class="input">
      ${materials.map(m => `<option value="${m.id}">${m.name}</option>`).join("")}
    </select>

    <button onclick="saveProduct()" class="btn-save">Speichern</button>
  `);
}

function saveProduct(){
  const name = document.getElementById("prod-name").value;
  const weight = parseFloat(document.getElementById("prod-weight").value);
  const materialId = parseInt(document.getElementById("prod-material").value);

  const mat = materials.find(m => m.id === materialId);
  const cost = (weight / 1000) * mat.price;

  products.push({ id: Date.now(), name, weight, materialId, cost });
  saveAll();
  renderProducts();
  closePanel();
}

function renderProducts(){
  const list=document.getElementById("product-list");
  list.innerHTML="";
  products.forEach(p=>{
    const mat=materials.find(m=>m.id===p.materialId);
    list.innerHTML+=`<div class="card">
      <strong>${p.name}</strong><br>
      Gewicht: ${p.weight} g<br>
      Material: ${mat?mat.name:"?"}<br>
      Kosten/Stück: ${p.cost.toFixed(2)} €<br>
      <button onclick="deleteProduct(${p.id})">Löschen</button>
    </div>`;
  });
}

function deleteProduct(id){
  products=products.filter(p=>p.id!==id);
  saveAll(); renderProducts();
}

/* ANGEBOTE */
function createOffer(){
  openPanel("Angebot erstellen", `
    <label>Titel</label>
    <input id="offer-title" type="text" class="input">

    <label>Produkt wählen</label>
    <select id="offer-product" class="input">
      ${products.map(p => `<option value="${p.id}">${p.name}</option>`).join("")}
    </select>

    <label>Menge</label>
    <input id="offer-qty" type="number" class="input">

    <button onclick="saveOffer()" class="btn-save">Speichern</button>
  `);
}

function saveOffer(){
  const title = document.getElementById("offer-title").value;
  const productId = parseInt(document.getElementById("offer-product").value);
  const qty = parseInt(document.getElementById("offer-qty").value);

  const p = products.find(x => x.id === productId);
  const total = p.cost * qty;

  offers.push({ id: Date.now(), title, productId, qty, total });
  saveAll();
  renderOffers();
  closePanel();
}

function renderOffers(){
  const list=document.getElementById("offer-list");
  list.innerHTML="";
  offers.forEach(o=>{
    const p=products.find(x=>x.id===o.productId);
    list.innerHTML+=`<div class="card">
      <strong>${o.title}</strong><br>
      Produkt: ${p?p.name:"?"}<br>
      Menge: ${o.qty}<br>
      Gesamt: ${o.total.toFixed(2)} €<br>
      <button onclick="exportOfferPDF(${o.id})">PDF</button>
      <button onclick="deleteOffer(${o.id})">Löschen</button>
    </div>`;
  });
}

function deleteOffer(id){
  offers=offers.filter(o=>o.id!==id);
  saveAll(); renderOffers();
}

/* PDF */
function exportOfferPDF(id){
  const o=offers.find(x=>x.id===id);
  const p=products.find(x=>x.id===o.productId);
  const m=materials.find(x=>x.id===p.materialId);

  const pdf=document.createElement("div");
  pdf.style.padding="40px";
  pdf.style.fontFamily="Arial";

  pdf.innerHTML=`
    <div style="display:flex;gap:20px;align-items:center;border-bottom:3px solid #2e7d32;padding-bottom:20px;margin-bottom:30px;">
      <div style="width:80px;height:80px;border-radius:8px;overflow:hidden;">
        <img src="logo.png" style="width:100%;height:100%;object-fit:cover;">
      </div>
      <div>
        <h1 style="margin:0;color:#2e7d32;">Jung Faserwerke – Angebot</h1>
        <p style="margin:0;">${new Date().toLocaleDateString()}</p>
      </div>
    </div>

    <h2 style="color:#2e7d32;">${o.title}</h2>

    <p><strong>Produkt:</strong> ${p.name}</p>
    <p><strong>Material:</strong> ${m.name}</p>
    <p><strong>Gewicht:</strong> ${p.weight} g</p>
    <p><strong>Kosten/Stück:</strong> ${p.cost.toFixed(2)} €</p>

    <p><strong>Menge:</strong> ${o.qty}</p>
    <p><strong>Gesamt:</strong> ${o.total.toFixed(2)} €</p>
  `;

  html2pdf().from(pdf).save(o.title+".pdf");
}

/* DARK MODE */
function toggleDarkMode(){
  document.body.classList.toggle("dark");
}

/* INITIAL */
renderMaterials();
renderProducts();
renderOffers();